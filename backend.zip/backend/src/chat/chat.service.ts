import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { Chat } from '../schemas/chat.schema';
import { Conversation } from '../schemas/conversation.schema';
import { PromptRouterService } from './prompt-router.service';
import { OllamaService } from './ollama.service';

@Injectable()
export class ChatService {
  private readonly logger = new Logger(ChatService.name);

  constructor(
    @InjectModel(Chat.name) private chatModel: Model<Chat>,
    @InjectModel(Conversation.name) private conversationModel: Model<Conversation>,
    private readonly promptRouterService: PromptRouterService,
    private readonly ollamaService: OllamaService,
    private readonly configService: ConfigService,
  ) { }

  async sendMessage(userEmail: string, message: string, conversationId?: string, requestedModel?: string) {
    let finalConvId = conversationId;

    if (!finalConvId) {
      const titleLength = this.configService.get<number>('CHAT_TITLE_LENGTH') || 30;
      const title = message.substring(0, titleLength) + "...";
      const newConv = new this.conversationModel({
        userEmail: userEmail,
        title: title
      });
      const savedConv = await newConv.save();
      finalConvId = savedConv._id.toString();
    }

    // Determine model and metadata
    let routingResult;
    let selectedModel;

    if (!requestedModel || requestedModel === 'auto') {
      // Route prompt to find domain, complexity, and target model
      routingResult = await this.promptRouterService.routePrompt(message);
      selectedModel = routingResult.model;
    } else {
      selectedModel = requestedModel;
      routingResult = {
        model: requestedModel,
        domain: 'user-selected',
        complexity: 'unknown'
      };
    }

    let aiResponseText = "Error";
    let responseTimeMs = 0;
    try {
      this.logger.log(`${userEmail} Sending to Ollama [${selectedModel}]: ${message.substring(0, 50)}...`);

      const startTime = Date.now();
      aiResponseText = await this.ollamaService.generateResponse(selectedModel, message);
      responseTimeMs = Date.now() - startTime;

      this.logger.log(`${selectedModel} replied ${userEmail}: ${aiResponseText.substring(0, 50)}... (took ${responseTimeMs}ms)`);

    } catch (error) {
      this.logger.error(`Ollama connection failed: ${error.message}`);
      aiResponseText = "I'm sorry, my brain is offline. Please check the server logs.";
    }

    const newChat = new this.chatModel({
      conversationId: new Types.ObjectId(finalConvId),
      userEmail: userEmail,
      message: message,
      response: aiResponseText,
      aiModel: selectedModel,
      responseTimeMs: responseTimeMs,
      domain: routingResult?.domain || 'unknown',
      complexity: routingResult?.complexity || 'unknown',
    });

    await newChat.save();

    return {
      response: aiResponseText,
      conversationId: finalConvId,
      aiModel: selectedModel,
      routingDetails: routingResult // Returning metadata including routing info
    };
  }

  async getUserConversations(userEmail: string, skip = 0, limit = 10) {
    return this.conversationModel
      .find({ userEmail })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .exec();
  }

  async getMessagesForConversation(userEmail: string, conversationId: string) {
    return this.chatModel
      .find({
        userEmail: userEmail,
        conversationId: new Types.ObjectId(conversationId)
      })
      .sort({ createdAt: 1 })
      .exec();
  }

  async getPerformanceMetrics() {
    return this.chatModel.aggregate([
      {
        $group: {
          _id: { model: "$aiModel", domain: "$domain" },
          averageResponseTimeMs: { $avg: "$responseTimeMs" },
          count: { $sum: 1 }
        }
      },
      {
        $project: {
          _id: 0,
          model: "$_id.model",
          domain: "$_id.domain",
          averageResponseTimeMs: { $round: ["$averageResponseTimeMs", 2] },
          count: 1
        }
      },
      { $sort: { model: 1, domain: 1 } }
    ]).exec();
  }

  async getRoutingMetrics() {
    return this.chatModel.aggregate([
      {
        $group: {
          _id: { domain: "$domain", complexity: "$complexity" },
          count: { $sum: 1 }
        }
      },
      {
        $project: {
          _id: 0,
          domain: "$_id.domain",
          complexity: "$_id.complexity",
          count: 1
        }
      },
      { $sort: { count: -1 } }
    ]).exec();
  }
}